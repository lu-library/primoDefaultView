(function () {
	"use strict";
	'use strict';

	var app = angular.module('viewCustom', ['angularLoad']);
	
	/*----------below is the code for libraryh3lp -----------*/
    (function() {
      var x = document.createElement("script"); x.type = "text/javascript"; x.async = true;
      x.src = (document.location.protocol === "https:" ? "https://" : "http://") + "ca.libraryh3lp.com/js/libraryh3lp.js?621";
      var y = document.getElementsByTagName("script")[0]; y.parentNode.insertBefore(x, y);
    })()
	/*----------End of library3lp --------------------------*/
})();

